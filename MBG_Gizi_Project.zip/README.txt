MBG GIZI V2 — ANDROID PROJECT

Project ini membungkus aplikasi MBG Gizi V2 menjadi aplikasi Android native sederhana.
Build dilakukan dengan Android Gradle Plugin. GitHub Actions disediakan agar APK dapat
dibuild dari cloud tanpa PC/laptop.

CARA BUILD DARI HP:
1. Buat akun GitHub gratis jika belum punya.
2. Buat repository baru, misalnya: mbg-gizi.
3. Upload seluruh isi ZIP ini ke repository (termasuk folder .github/workflows).
4. Buka tab Actions di repository.
5. Pilih "Build MBG Gizi APK" lalu tekan "Run workflow" (atau lakukan push ke main).
6. Tunggu build selesai.
7. Buka hasil workflow yang sukses dan download artifact "MBG-Gizi-debug".
8. Ekstrak ZIP artifact dan ambil app-debug.apk.
9. Buka APK di Android dan izinkan pemasangan dari sumber yang diizinkan jika diminta.

CATATAN:
- APK ini adalah debug build untuk penggunaan/pengujian pribadi.
- Database bawaan hanya contoh. Jangan menganggapnya sebagai database resmi TKPI/NutriSurvey.
- Versi berikutnya dapat mengganti asset/index.html dengan versi kalkulator yang lebih lengkap,
  menambahkan database resmi berlisensi, AKG lengkap, ekspor Excel/PDF, dan template poster A4.
